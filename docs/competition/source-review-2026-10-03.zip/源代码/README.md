# 校园工具源码审查包

本包不是正式参赛包。原课表夹具含个人信息，整个tests目录和旧截图均未附。
Node.js ≥22：npm ci --ignore-scripts → npm run typecheck → npm run build。微信开发者工具导入dist。
完整回归测试与文档检查在交付仓库执行，不在本审查包声称复现；云密钥由服务端环境提供。
七项内部说明、v2.1展示材料、真实评测及待办请在交付PR查阅。正式名称、最终视频与人类验收/提交回执仍缺。
源码字节由manifest.json逐文件绑定；若snapshot标working_tree，不能误称全部字节来自所列HEAD提交。
